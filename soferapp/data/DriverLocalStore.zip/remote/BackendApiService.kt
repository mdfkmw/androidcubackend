package ro.priscom.sofer.ui.data.remote

import com.google.gson.annotations.SerializedName
import okhttp3.JavaNetCookieJar
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST
import java.net.CookieManager
import java.net.CookiePolicy

// === DTO-uri pentru /api/auth/login ===

data class LoginRequest(
    val identifier: String,
    val password: String
)

data class AuthUserDto(
    val id: Int,
    val role: String,
    val operator_id: Int?,
    val name: String?,
    val email: String?,
    val username: String?
)

data class LoginResponse(
    val ok: Boolean,
    val user: AuthUserDto?
)

// === DTO-uri pentru master data ===

data class OperatorDto(
    val id: Int,
    val name: String
)

data class EmployeeDto(
    val id: Int,
    val name: String,
    val role: String,
    val operator_id: Int?
)

data class VehicleDto(
    val id: Int,
    @SerializedName("plate_number") val plateNumber: String,
    @SerializedName("operator_id") val operatorId: Int
)

data class RouteDto(
    val id: Int,
    val name: String,
    val order_index: Int,
    val visible_for_drivers: Boolean
)

data class StationDto(
    val id: Int,
    val name: String
)

data class RouteStationDto(
    val id: Int,
    val route_id: Int,
    val station_id: Int,
    val order_index: Int,
    val geofence_type: String?,        // "circle" / "polygon" / null
    val geofence_radius: Double?,      // pentru circle
    val geofence_polygon: List<List<Double>>? // [[lat, lng], [lat, lng], ...]
)

data class PriceListDto(
    val id: Int,
    val route_id: Int,
    val category_id: Int,
    val effective_from: String
)

data class PriceListItemDto(
    val id: Int,
    val price: Double,
    val currency: String,
    val price_list_id: Int,
    val from_station_id: Int,
    val to_station_id: Int
)

// === Definiția Retrofit pentru backend ===

interface BackendApiService {

    @POST("/api/auth/login")
    suspend fun login(
        @Body body: LoginRequest
    ): LoginResponse

    // --- MASTER DATA ---

    @GET("/api/operators")
    suspend fun getOperators(): List<OperatorDto>

    @GET("/api/employees")
    suspend fun getEmployees(): List<EmployeeDto>

    @GET("/api/vehicles")
    suspend fun getVehicles(): List<VehicleDto>

    // --- RUTE / STAȚII / PREȚURI pentru aplicația de șofer ---

    // Rute vizibile pentru șofer, filtrate pe o dată
    @GET("/api/routes")
    suspend fun getRoutesForDriver(
        @retrofit2.http.Query("date") date: String,
        @retrofit2.http.Query("driver") driver: Int = 1
    ): List<RouteDto>

    // Toate stațiile (dacă ai dat acces driver la /api/stations)
    @GET("/api/stations")
    suspend fun getStations(): List<StationDto>

    // Legăturile route_stations (dacă ai creat endpoint-ul nou)
    @GET("/api/route_stations")
    suspend fun getRouteStations(): List<RouteStationDto>

    // Liste de preț
    @GET("/api/price-lists")
    suspend fun getPriceLists(): List<PriceListDto>

    // Articolele dintr-o listă de preț
    @GET("/api/price-lists/{id}/items")
    suspend fun getPriceListItems(
        @retrofit2.http.Path("id") id: Int
    ): List<PriceListItemDto>


    @GET("/api/routes")
    suspend fun getRoutes(): List<RouteDto>

    @GET("/api/price_list_items")
    suspend fun getPriceListItems(): List<PriceListItemDto>

}

// === Singleton pentru Retrofit + cookie-uri de sesiune ===

object BackendApi {

    private const val BASE_URL = "http://10.0.2.2:5000/"

    private val cookieManager = CookieManager().apply {
        setCookiePolicy(CookiePolicy.ACCEPT_ALL)
    }

    private val okHttpClient: OkHttpClient by lazy {
        val logger = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }

        OkHttpClient.Builder()
            .cookieJar(JavaNetCookieJar(cookieManager))
            .addInterceptor(logger)
            .build()
    }

    val service: BackendApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(BackendApiService::class.java)
    }
}
